var searchData=
[
  ['windowtitlefilter',['WindowTitleFilter',['../class_window_title_filter.html',1,'']]]
];
