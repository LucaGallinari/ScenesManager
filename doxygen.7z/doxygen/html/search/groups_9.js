var searchData=
[
  ['native_20codecs',['Native Codecs',['../group__lavc__codec__native.html',1,'']]],
  ['native_20demuxers',['Native Demuxers',['../group__lavf__codec__native.html',1,'']]]
];
