var searchData=
[
  ['qvideodecoder',['QVideoDecoder',['../class_q_video_decoder.html',1,'']]]
];
