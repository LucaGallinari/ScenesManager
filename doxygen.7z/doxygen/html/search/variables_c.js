var searchData=
[
  ['name',['name',['../structffmpeg_1_1_a_v_codec_descriptor.html#abada6c03e07ec728a59e898bc70c54db',1,'ffmpeg::AVCodecDescriptor::name()'],['../structffmpeg_1_1_a_v_profile.html#a60a0e464f7925a98c6eed70bfb83e2b7',1,'ffmpeg::AVProfile::name()'],['../structffmpeg_1_1_a_v_codec.html#a657c4ee10c7d0dc5be543bba3328b67d',1,'ffmpeg::AVCodec::name()'],['../structffmpeg_1_1_a_v_h_w_accel.html#a3fe9c9b073aa39134ccce9cd5c5f2cb5',1,'ffmpeg::AVHWAccel::name()'],['../structffmpeg_1_1_a_v_i_o_dir_entry.html#a9cfa12ea9071450c7ae3427b23cfbbe9',1,'ffmpeg::AVIODirEntry::name()'],['../structffmpeg_1_1_a_v_input_format.html#a6b83213e03a39338ad60de2b3d1423b0',1,'ffmpeg::AVInputFormat::name()']]],
  ['nb_5fchapters',['nb_chapters',['../structffmpeg_1_1_a_v_format_context.html#a14213c8573ecfc7ba4615cf8633cb27a',1,'ffmpeg::AVFormatContext']]],
  ['nb_5fcolors',['nb_colors',['../structffmpeg_1_1_a_v_subtitle_rect.html#ab55501011b24238ce74bb2f106240555',1,'ffmpeg::AVSubtitleRect']]],
  ['nb_5fdecoded_5fframes',['nb_decoded_frames',['../structffmpeg_1_1_a_v_stream.html#af250f0270a2580b3c8a457eb7d3b41b7',1,'ffmpeg::AVStream']]],
  ['nb_5fframes',['nb_frames',['../structffmpeg_1_1_a_v_stream.html#abe1131cf3287333286176d4e43f8db31',1,'ffmpeg::AVStream']]],
  ['nb_5fside_5fdata',['nb_side_data',['../structffmpeg_1_1_a_v_stream.html#a0349e00ae8d9884b0a437fbccf45f83f',1,'ffmpeg::AVStream']]],
  ['nb_5fstreams',['nb_streams',['../structffmpeg_1_1_a_v_format_context.html#a0f6a650731293d0ac75d3c8708193967',1,'ffmpeg::AVFormatContext']]],
  ['noise_5freduction',['noise_reduction',['../structffmpeg_1_1_a_v_codec_context.html#a1aefac0c199e01d07282f03b9ff0bc0d',1,'ffmpeg::AVCodecContext']]],
  ['nsse_5fweight',['nsse_weight',['../structffmpeg_1_1_a_v_codec_context.html#a4155a5e269190f0a52ecadd73e7a036a',1,'ffmpeg::AVCodecContext']]],
  ['num',['num',['../structffmpeg_1_1_a_v_rational.html#affcd09694e298373bf7637be830bcc73',1,'ffmpeg::AVRational::num()'],['../struct_frame.html#a3843b4a0cdf51eb0f9e97c89e0558de6',1,'Frame::num()']]]
];
