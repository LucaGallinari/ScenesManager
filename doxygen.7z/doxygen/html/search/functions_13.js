var searchData=
[
  ['windowtitlefilter',['WindowTitleFilter',['../class_window_title_filter.html#a2599f601dea85f138a72f5d643cad66d',1,'WindowTitleFilter']]]
];
