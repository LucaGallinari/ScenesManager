var searchData=
[
  ['playerwidget',['PlayerWidget',['../class_player_widget.html',1,'']]],
  ['previewswidget',['PreviewsWidget',['../class_previews_widget.html',1,'']]]
];
