var searchData=
[
  ['avaudioservicetype',['AVAudioServiceType',['../group__lavc__core.html#ga8e6d069d602b884a84961906f5b8f760',1,'ffmpeg']]],
  ['avcodecid',['AVCodecID',['../group__lavc__core.html#ga6c4ed6bd8e0006548bfbb56881ba83f8',1,'ffmpeg']]],
  ['avdiscard',['AVDiscard',['../group__lavc__decoding.html#ga8f495be7a05f470186b6125ddf200ea2',1,'ffmpeg']]],
  ['avlockop',['AVLockOp',['../group__lavc__misc.html#ga1fb0300d8545729b19ae10a9ed544170',1,'ffmpeg']]],
  ['avpacketsidedatatype',['AVPacketSideDataType',['../group__lavc__packet.html#gad3fc3c4fa06e747d890ff33873cdcf4d',1,'ffmpeg']]],
  ['avsubtitletype',['AVSubtitleType',['../group__lavc__core.html#gaf4d94852595231c2c093a96e180001f2',1,'ffmpeg']]]
];
