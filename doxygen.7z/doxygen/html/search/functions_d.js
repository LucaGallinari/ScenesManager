var searchData=
[
  ['pausevideo',['pauseVideo',['../class_player_widget.html#ac09a6b384bd4b667a77c0ad7c0c1d5c0',1,'PlayerWidget']]],
  ['playerwidget',['PlayerWidget',['../class_player_widget.html#ab8b227eb6ec40c9a011402f5b54d9fce',1,'PlayerWidget']]],
  ['playpause',['playPause',['../class_player_widget.html#a8ab0df49c1679b111e558589960d7bb3',1,'PlayerWidget']]],
  ['playvideo',['playVideo',['../class_player_widget.html#aac133b3be92e4cd1720c70f61d1916a0',1,'PlayerWidget']]],
  ['prevframe',['prevFrame',['../class_player_widget.html#ac28d0b584b9eb39d0f8a65e8fae3c54c',1,'PlayerWidget']]],
  ['previewswidget',['PreviewsWidget',['../class_previews_widget.html#ad69d59e27f50b3a0a4e2116dbcc8a842',1,'PreviewsWidget']]]
];
