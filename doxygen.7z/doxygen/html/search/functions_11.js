var searchData=
[
  ['titlebar',['TitleBar',['../class_title_bar.html#abe43dd29802ce16372f4b82679ad5c19',1,'TitleBar']]],
  ['titlechanged',['titleChanged',['../class_title_bar.html#afdf379f18c99862a811e2ea85ec5e1d4',1,'TitleBar']]]
];
