var searchData=
[
  ['loadfile',['loadFile',['../class_markers_widget.html#a35f84698b5fe901159a4d6440cdd9581',1,'MarkersWidget']]],
  ['loadvideo',['loadVideo',['../class_images_buffer.html#ab4b1b5ce6c5799779496d54c7c03d128',1,'ImagesBuffer::loadVideo()'],['../class_player_widget.html#a4d76d2654882fce864f9acd18a3b35bb',1,'PlayerWidget::loadVideo()']]]
];
