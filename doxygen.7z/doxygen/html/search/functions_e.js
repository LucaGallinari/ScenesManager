var searchData=
[
  ['qvideodecoder',['QVideoDecoder',['../class_q_video_decoder.html#ae0f610cd14d024203547e253c26f6060',1,'QVideoDecoder::QVideoDecoder()'],['../class_q_video_decoder.html#a6304941d43e4b58b9d1d70b03f802bfb',1,'QVideoDecoder::QVideoDecoder(const QString file)']]]
];
