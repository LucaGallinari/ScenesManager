var searchData=
[
  ['changeplaypause',['changePlayPause',['../class_main_window.html#ac27c92f017e607ceaa230595c0004651',1,'MainWindow']]],
  ['changestartendbtn',['changeStartEndBtn',['../class_main_window.html#a5a69bd58ab489f03f245910e53d62667',1,'MainWindow']]],
  ['clearpreviews',['clearPreviews',['../class_previews_widget.html#aa2ad905324aadbd07d5e0b46fedaee46',1,'PreviewsWidget']]],
  ['close',['close',['../class_q_video_decoder.html#ab343600a3cf40448484e0b493181a329',1,'QVideoDecoder']]],
  ['comparemarkersdialog',['CompareMarkersDialog',['../class_compare_markers_dialog.html#a1b60afe054c9e0b3e11d679ffc0d9fcc',1,'CompareMarkersDialog']]],
  ['correctseektokeyframe',['correctSeekToKeyFrame',['../class_q_video_decoder.html#ad332b92281ff83d6369fabfe71d0dac4',1,'QVideoDecoder']]],
  ['currentframenumber',['currentFrameNumber',['../class_player_widget.html#ad94e2f5feba8013fb60a3093d121f1ab',1,'PlayerWidget']]],
  ['currentframetime',['currentFrameTime',['../class_player_widget.html#afcfc4f9263c6c1ea56ce37a4df5a0aac',1,'PlayerWidget']]],
  ['currenttimepercentage',['currentTimePercentage',['../class_player_widget.html#a2f7f67b9fad730fecfc52364bfd8a08c',1,'PlayerWidget']]]
];
