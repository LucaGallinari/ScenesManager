var searchData=
[
  ['avhwaccel',['AVHWAccel',['../group__lavc__hwaccel.html',1,'']]],
  ['avpacket',['AVPacket',['../group__lavc__packet.html',1,'']]],
  ['avpicture',['AVPicture',['../group__lavc__picture.html',1,'']]],
  ['audio_20resampling',['Audio resampling',['../group__lavc__resample.html',1,'']]]
];
