var searchData=
[
  ['lavu_5fmath',['Lavu_math',['../group__lavu__math.html',1,'']]]
];
