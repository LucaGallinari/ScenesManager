var searchData=
[
  ['last_5fdiscard_5fsample',['last_discard_sample',['../structffmpeg_1_1_a_v_stream.html#afab8e591e454a87c3c311753d8aa9cb3',1,'ffmpeg::AVStream']]],
  ['last_5fdts_5ffor_5forder_5fcheck',['last_dts_for_order_check',['../structffmpeg_1_1_a_v_stream.html#a5a235db2399eff6ae02df429aa1792bf',1,'ffmpeg::AVStream']]],
  ['last_5fin_5fpacket_5fbuffer',['last_in_packet_buffer',['../structffmpeg_1_1_a_v_stream.html#a6c0897ae60398a43462d9e5f3fb53e1d',1,'ffmpeg::AVStream']]],
  ['last_5fpos',['last_pos',['../structffmpeg_1_1_a_v_codec_parser_context.html#ab5cbb95106b4b8e8a52942f7a0dcbcc6',1,'ffmpeg::AVCodecParserContext']]],
  ['last_5fpredictor_5fcount',['last_predictor_count',['../structffmpeg_1_1_a_v_codec_context.html#a8d10c56c66338e6813767f2f207a6b5f',1,'ffmpeg::AVCodecContext']]],
  ['lastframeok',['LastFrameOk',['../class_q_video_decoder.html#a6b6f9ad0bed753bc3612cc4e5844571a',1,'QVideoDecoder']]],
  ['length',['length',['../structffmpeg_1_1_sws_vector.html#a139214525f3256869af211edc654ee6d',1,'ffmpeg::SwsVector']]],
  ['level',['level',['../structffmpeg_1_1_a_v_codec_context.html#a0526e9e7ce578d01b7e76dec003f0337',1,'ffmpeg::AVCodecContext']]],
  ['linesize',['linesize',['../structffmpeg_1_1_a_v_picture.html#a388e1abee876f75c2d8f867e88284930',1,'ffmpeg::AVPicture']]],
  ['lmax',['lmax',['../structffmpeg_1_1_a_v_codec_context.html#a905f525117e529bba32b3da431fd05e8',1,'ffmpeg::AVCodecContext']]],
  ['lmin',['lmin',['../structffmpeg_1_1_a_v_codec_context.html#a4ea6a6a6d07001650e1a9201a5fa3378',1,'ffmpeg::AVCodecContext']]],
  ['long_5fname',['long_name',['../structffmpeg_1_1_a_v_codec_descriptor.html#a11650376015d8f2657f8bf5a9c2d8198',1,'ffmpeg::AVCodecDescriptor::long_name()'],['../structffmpeg_1_1_a_v_codec.html#a05afbb392953309505f4948f853ca76b',1,'ffmpeg::AVCodec::long_name()'],['../structffmpeg_1_1_a_v_output_format.html#ad249a2658ae7373b72babf4562717e05',1,'ffmpeg::AVOutputFormat::long_name()'],['../structffmpeg_1_1_a_v_input_format.html#a358d0734ad6f1068e842fca535728a3c',1,'ffmpeg::AVInputFormat::long_name()']]],
  ['lowres',['lowres',['../structffmpeg_1_1_a_v_codec_context.html#a637ab96a388d42e672843e67bcd8a05a',1,'ffmpeg::AVCodecContext']]],
  ['lumi_5fmasking',['lumi_masking',['../structffmpeg_1_1_a_v_codec_context.html#a3f6843909ce7a2e5253fd6022faf6d6f',1,'ffmpeg::AVCodecContext']]]
];
