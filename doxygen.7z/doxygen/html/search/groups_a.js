var searchData=
[
  ['pixel_20formats',['Pixel formats',['../group__lavc__misc__pixfmt.html',1,'']]],
  ['public_20metadata_20api',['Public Metadata API',['../group__metadata__api.html',1,'']]]
];
