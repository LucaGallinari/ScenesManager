var searchData=
[
  ['h',['h',['../structffmpeg_1_1_a_v_subtitle_rect.html#a7e23c11b74fd72ee65bd56c76f3f42db',1,'ffmpeg::AVSubtitleRect::h()'],['../class_q_video_decoder.html#ac61b3ea9cbebabe4df73283a72f8a089',1,'QVideoDecoder::h()']]],
  ['has_5fb_5fframes',['has_b_frames',['../structffmpeg_1_1_a_v_codec_context.html#a0165524a4a7d89f1dfa139b31bb3c4e9',1,'ffmpeg::AVCodecContext']]],
  ['hovermovefilter',['HoverMoveFilter',['../class_hover_move_filter.html',1,'HoverMoveFilter'],['../class_hover_move_filter.html#a6a189b700da540f2eaa49c82ea1cf6f7',1,'HoverMoveFilter::HoverMoveFilter()']]],
  ['hwaccel',['hwaccel',['../structffmpeg_1_1_a_v_codec_context.html#afed8626f04d922086167dba9cc3a4d21',1,'ffmpeg::AVCodecContext']]],
  ['hwaccel_5fcodec_5fcap_5fexperimental',['HWACCEL_CODEC_CAP_EXPERIMENTAL',['../group__lavc__core.html#ga6123ca58364d461679bed5c726aa0c82',1,'ffmpeg.h']]],
  ['hwaccel_5fcontext',['hwaccel_context',['../structffmpeg_1_1_a_v_codec_context.html#a861471969eef0793ee8aa43c86ba2ec4',1,'ffmpeg::AVCodecContext']]],
  ['hardware_20accelerators_20bridge',['Hardware Accelerators bridge',['../group__lavc__codec__hwaccel.html',1,'']]]
];
