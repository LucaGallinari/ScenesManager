var searchData=
[
  ['key_5fframe',['key_frame',['../structffmpeg_1_1_a_v_codec_parser_context.html#a1c5a54ef82a9f8b3e05f5e4232baeaaf',1,'ffmpeg::AVCodecParserContext']]],
  ['keyint_5fmin',['keyint_min',['../structffmpeg_1_1_a_v_codec_context.html#a502deb793581b15cecb60df418de4228',1,'ffmpeg::AVCodecContext']]]
];
