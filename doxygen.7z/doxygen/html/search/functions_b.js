var searchData=
[
  ['newfile',['newFile',['../class_markers_widget.html#ad4cb7236f8818a85a65b910287829d22',1,'MarkersWidget']]],
  ['nextframe',['nextFrame',['../class_player_widget.html#a1344ea05d03a4b81361afc18583c82fa',1,'PlayerWidget']]],
  ['nextsingleframe',['nextSingleFrame',['../class_player_widget.html#a94c76e3037eb3f411eae604cc996278a',1,'PlayerWidget']]]
];
