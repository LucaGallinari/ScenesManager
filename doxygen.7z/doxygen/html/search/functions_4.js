var searchData=
[
  ['filenotsaved',['fileNotSaved',['../class_markers_widget.html#a9cc33c979183a9eefa4d833a25571ebd',1,'MarkersWidget']]]
];
