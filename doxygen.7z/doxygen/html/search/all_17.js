var searchData=
[
  ['x',['x',['../structffmpeg_1_1_a_v_subtitle_rect.html#add4c33995ac3c3c459fb05cfa62334f3',1,'ffmpeg::AVSubtitleRect']]],
  ['xvmc_5facceleration',['xvmc_acceleration',['../structffmpeg_1_1_a_v_codec_context.html#a681a45fc856abc684ab20c17d94b8343',1,'ffmpeg::AVCodecContext']]]
];
