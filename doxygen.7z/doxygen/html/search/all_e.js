var searchData=
[
  ['offset',['offset',['../structffmpeg_1_1_a_v_codec_parser_context.html#acf326e31a07684a3b93fc245cea19175',1,'ffmpeg::AVCodecParserContext']]],
  ['oformat',['oformat',['../structffmpeg_1_1_a_v_format_context.html#a17e952614ad8a1dc0956df7d3218e80b',1,'ffmpeg::AVFormatContext']]],
  ['opaque',['opaque',['../structffmpeg_1_1_a_v_codec_context.html#ad9d7b3a12f9399655a2b720142e9c02c',1,'ffmpeg::AVCodecContext::opaque()'],['../structffmpeg_1_1_a_v_i_o_context.html#a0159831c9433da34b6c649f4979066a2',1,'ffmpeg::AVIOContext::opaque()'],['../structffmpeg_1_1_a_v_format_context.html#a1ff1f4351f74cb7e330084c929b24dc4',1,'ffmpeg::AVFormatContext::opaque()']]],
  ['open_5fcb',['open_cb',['../structffmpeg_1_1_a_v_format_context.html#aa4f7c1f98b10065440710ea5d25583fc',1,'ffmpeg::AVFormatContext']]],
  ['openfile',['openFile',['../class_q_video_decoder.html#abc55c8ce176b7e34693b2a0dffc5af1d',1,'QVideoDecoder']]],
  ['orig_5fbuffer_5fsize',['orig_buffer_size',['../structffmpeg_1_1_a_v_i_o_context.html#aa366e58b8e13652c69a7e30f2a291e47',1,'ffmpeg::AVIOContext']]],
  ['output_5fpicture_5fnumber',['output_picture_number',['../structffmpeg_1_1_a_v_codec_parser_context.html#a9f8bc4cd099ff3c97ea854eac230c29c',1,'ffmpeg::AVCodecParserContext']]],
  ['output_5fts_5foffset',['output_ts_offset',['../structffmpeg_1_1_a_v_format_context.html#a9ac7cefba444ee1a71aa4fd75e750418',1,'ffmpeg::AVFormatContext']]]
];
